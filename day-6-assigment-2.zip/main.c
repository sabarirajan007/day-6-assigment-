#include <stdio.h>

int main() {
    int num, i, fact = 1;

    printf("Enter a positive integer: ");
    scanf("%d", &num);

    // calculate factorial
    for (i = 1; i <= num; i++) {
        fact = fact * i;
    }

    // display result
    printf("Factorial of %d = %d\n", num, fact);

    return 0;
}
